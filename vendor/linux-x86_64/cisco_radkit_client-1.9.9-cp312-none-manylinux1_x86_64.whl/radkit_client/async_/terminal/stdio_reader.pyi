from _typeshed import Incomplete
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

__all__ = ['StdioReader', 'STYLE', 'Flush@52', 'Done@55', 'Flush', 'Done']

class StdioReader:
    def __init__(self, help_text: str) -> None: ...
    @asynccontextmanager
    async def read_input(self) -> AsyncGenerator[AsyncGenerator[bytes]]: ...

STYLE: Incomplete

# Names in __all__ with no definition:
#   Done
#   Done@55
#   Flush
#   Flush@52
